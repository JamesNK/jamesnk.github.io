﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Caching;

namespace JsonFormat.Web.Mvc.Models
{
  public class PerformanceKiller
  {
    private static readonly TimeSpan ActiveTime = TimeSpan.FromMinutes(2.5);

    public string ServerAddress;
    private readonly PerformanceCounter _cpuCounter;
    private readonly PerformanceCounter _ramCounter;

    public PerformanceKiller()
    {
      _cpuCounter = new PerformanceCounter();

      _cpuCounter.CategoryName = "Processor";
      _cpuCounter.CounterName = "% Processor Time";
      _cpuCounter.InstanceName = "_Total";

      _ramCounter = new PerformanceCounter("Memory", "Available MBytes");
    }

    public void EnableCpuUsage()
    {
      for (int i = 0; i < Environment.ProcessorCount; i++)
      {
        Task.Run(
          () =>
          {
            DateTime startDate = DateTime.Now;
            while (DateTime.Now - startDate < ActiveTime)
            {
              // don't do anything
            }
          });
      }
    }

    private readonly IList<IList<byte[]>> _dataArrays = new List<IList<byte[]>>();

    public void EnableMemoryUsage()
    {
      Task.Run(
        () =>
          {
            IList<byte[]> arrays = new List<byte[]>();

            for (int i = 0; i < 100; i++)
            {
              byte[] data = new byte[10485760];
              for (int j = 0; j < data.Length; j++)
              {
                data[j] = 0xff;
              }

              arrays.Add(data);
            }

            try
            {
              _dataArrays.Add(arrays);

              Thread.Sleep(ActiveTime);
            }
            finally
            {
              _dataArrays.Remove(arrays);
            }

          });
    }

    public void EnableDosAttack()
    {
      for (int i = 0; i <= 10; i++) // 10 threads getting the page
      {
        Task.Run(
          () =>
          {
            DateTime startDate = DateTime.Now;
            while (DateTime.Now - startDate < ActiveTime)
            {
              WebRequest r = WebRequest.Create(ServerAddress);
              using (WebResponse response = r.GetResponse())
              using (Stream responseStream = response.GetResponseStream())
              using (StreamReader reader = new StreamReader(responseStream))
              {
                reader.ReadToEnd();
              }
              // don't do anything
            }
          });
      }
    }

    public int GetCurrentCpuUsage()
    {
      return Convert.ToInt32(_cpuCounter.NextValue());
    }

    public int GetAvailableRam()
    {
      return Convert.ToInt32(_ramCounter.NextValue());
    }

    public void EnableFileNotFoundErrors()
    {
      HttpRuntime.Cache.Add("FileNotFoundErrors", true, null, DateTime.Now.Add(ActiveTime), Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
    }

    public void EnableServerErrors()
    {
      HttpRuntime.Cache.Add("ServerErrors", true, null, DateTime.Now.Add(ActiveTime), Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
    }

    public void EnableSlowResponseTime()
    {
      HttpRuntime.Cache.Add("SlowResponseTime", true, null, DateTime.Now.Add(ActiveTime), Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
    }

    public bool SlowResponseTimeEnabled
    {
      get { return (bool) (HttpRuntime.Cache["SlowResponseTime"] ?? false); }
    }

    public bool ServerErrorsEnabled
    {
      get { return (bool) (HttpRuntime.Cache["ServerErrors"] ?? false); }
    }

    public bool FileNotFoundErrorsEnabled
    {
      get { return (bool) (HttpRuntime.Cache["FileNotFoundErrors"] ?? false); }
    }

    public void HandleRequest()
    {
      if (ServerErrorsEnabled)
        throw new Exception("Server error.");

      if (FileNotFoundErrorsEnabled)
        throw new HttpException(404, "File not found error.");

      if (SlowResponseTimeEnabled)
      {
        int milliseconds = 1000;
        milliseconds += (new Random()).Next(0, 9000);

        Thread.Sleep(milliseconds);
      }
    }
  }
}