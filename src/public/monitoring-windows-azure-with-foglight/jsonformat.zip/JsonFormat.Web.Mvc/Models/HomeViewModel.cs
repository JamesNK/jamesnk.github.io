﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JsonFormat.Web.Mvc.Models
{
  public class HomeViewModel
  {
    public string OriginalJson { get; set; }
    public string FormattedJson { get; set; }
  }
}