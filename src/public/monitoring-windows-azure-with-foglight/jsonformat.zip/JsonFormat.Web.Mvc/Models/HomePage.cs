﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JsonFormat.Web.Mvc.Models
{
  public class HomePage
  {
    public HomeViewModel ViewModel { get; set; }

    public int CpuUsage { get; set; }
    public int MemoryAvailable { get; set; }
  }
}