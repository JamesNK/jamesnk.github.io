﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using JsonFormat.Web.Mvc.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace JsonFormat.Web.Mvc.Controllers
{
  public class HomeController : Controller
  {
    private static readonly PerformanceKiller PerformanceKiller = new PerformanceKiller();

    public ActionResult Index()
    {
      if (string.IsNullOrEmpty(PerformanceKiller.ServerAddress))
        PerformanceKiller.ServerAddress = Request.Url.AbsoluteUri;

      PerformanceKiller.HandleRequest();

      return View(CreatePage(new HomeViewModel()));
    }

    [HttpPost]
    public ActionResult Index(HomeViewModel viewModel)
    {
      PerformanceKiller.HandleRequest();

      ModelState.Clear();

      if (!string.IsNullOrEmpty(viewModel.OriginalJson))
      {
        try
        {
          JToken json = JToken.Parse(viewModel.OriginalJson);
          viewModel.FormattedJson = json.ToString(Formatting.Indented);
        }
        catch (Exception ex)
        {
          viewModel.FormattedJson = ex.Message;
        }
      }
      else
      {
        viewModel.FormattedJson = string.Empty;
      }

      return View(CreatePage(viewModel));
    }

    private HomePage CreatePage(HomeViewModel model)
    {
      HomePage p = new HomePage();
      p.ViewModel = model;
      p.CpuUsage = PerformanceKiller.GetCurrentCpuUsage();
      p.MemoryAvailable = PerformanceKiller.GetAvailableRam();

      return p;
    }

    public ActionResult ChangeSetting(string setting)
    {
      switch (setting)
      {
        case Constants.SettingButtons.CpuUsage:
          PerformanceKiller.EnableCpuUsage();
          break;
        case Constants.SettingButtons.MemoryUsage:
          PerformanceKiller.EnableMemoryUsage();
          break;
        case Constants.SettingButtons.DosAttack:
          PerformanceKiller.EnableDosAttack();
          break;
        case Constants.SettingButtons.NotFoundErrors:
          PerformanceKiller.EnableFileNotFoundErrors();
          break;
        case Constants.SettingButtons.ServerErrors:
          PerformanceKiller.EnableServerErrors();
          break;
        case Constants.SettingButtons.SlowResponseTime:
          PerformanceKiller.EnableSlowResponseTime();
          break;
      }

      return RedirectToAction("Index", "Home");
    }
  }
}
