﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JsonFormat.Web.Mvc
{
  public static class Constants
  {
    public static class SettingButtons
    {
      public const string ServerErrors = "Server Errors";
      public const string NotFoundErrors = "404 Errors";
      public const string CpuUsage = "CPU Usage";
      public const string MemoryUsage = "Memory Usage";
      public const string SlowResponseTime = "Slow Response Time";
      public const string DosAttack = "DOS Attack";
    }
  }
}