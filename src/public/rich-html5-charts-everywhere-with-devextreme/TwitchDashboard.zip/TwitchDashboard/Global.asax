﻿<%@ Application Codebehind="Global.asax.cs" Inherits="TwitchDashboard.MvcApplication" Language="C#" %>
