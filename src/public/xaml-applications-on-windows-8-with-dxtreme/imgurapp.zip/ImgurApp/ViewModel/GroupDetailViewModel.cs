﻿using DevExpress.Core;
using DevExpress.Core.Navigation;
using DevExpress.UI.Xaml.Layout;

namespace ImgurApp.Data
{
    //A View Model for a GroupDetailPage
    public class GroupDetailViewModel : BindableBase, ISupportSaveLoadState
    {
        Album group;
        public GroupDetailViewModel() { }
        public Album Group
        {
            get { return group; }
            private set { SetProperty<Album>(ref group, value); }
        }

        void ISupportSaveLoadState.LoadState(object navigationParameter, PageStateStorage storage)
        {
            Album group = SampleDataSource.GetGroup((string)navigationParameter);
            Group = SampleDataSource.GetGroup((string)navigationParameter);
        }

        void ISupportSaveLoadState.SaveState(PageStateStorage storage)
        {
        }
    }
}
