﻿using DevExpress.Core;
using DevExpress.Core.Navigation;
using DevExpress.UI.Xaml.Layout;

namespace ImgurApp.Data
{
    //A View Model for an ItemDetailPage
    public class ItemDetailViewModel : BindableBase, ISupportSaveLoadState
    {
        Image selectedItem;
        Album group;
        public ItemDetailViewModel() { }

        public Image SelectedItem
        {
            get { return selectedItem; }
            set { SetProperty<Image>(ref selectedItem, value); }
        }

        public Album Group
        {
            get { return group; }
            private set { SetProperty<Album>(ref group, value); }
        }

        void Initialize(object parameter)
        {
            Image item = SampleDataSource.GetItem((string)parameter);
            Group = item.Album;
            SelectedItem = item;
        }

        void ISupportSaveLoadState.LoadState(object navigationParameter, PageStateStorage pageState)
        {
            Initialize(navigationParameter);
        }

        void ISupportSaveLoadState.SaveState(PageStateStorage pageState)
        {
            pageState.SaveParameter("SelectedItem", SelectedItem.Hash);
        }
    }
}
