﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExpress.Core;
using DevExpress.Core.Commands;
using DevExpress.Core.Navigation;
using DevExpress.UI.Xaml.Layout;
using System.Windows.Input;

namespace ImgurApp.Data
{
    //A View Model for a GroupedItemsPage
    public class GroupedItemsViewModel : BindableBase, ISupportSaveLoadState, ISupportServices
    {
        public ICommand AddSubReddit { get; private set; }

        private readonly ServiceContainer _serviceContainer;

        private ObservableCollection<Album> _albums;

        public GroupedItemsViewModel()
        {
            AddSubReddit = new DelegateCommand<object>(obj => LaunchDialog());
            _serviceContainer = new ServiceContainer();
        }

        private async void LaunchDialog()
        {
            Album s = new Album();
            s.Title = "all";

            IDialogService addSubRedditDialog = _serviceContainer.GetService<IDialogService>("editDialog");
            addSubRedditDialog.Content = s;

            var result = await addSubRedditDialog.ShowAsync();

            if (result == MessageDialogResult.OK)
            {
                var r = await Task.Run(() =>
                                           {
                                               var group = SampleDataSource.LoadAlbum("/r/" + s.Title).Result;
                                               return group;
                                           });

                _albums.Insert(0, r);
            }
        }

        public ObservableCollection<Album> Albums
        {
            get { return _albums; }
            private set { SetProperty(ref _albums, value); }
        }

        void ISupportSaveLoadState.LoadState(object navigationParameter, PageStateStorage pageState)
        {
            Albums = SampleDataSource.GetGroups((string) navigationParameter);
        }

        void ISupportSaveLoadState.SaveState(PageStateStorage pageState)
        {
        }

        public ServiceContainer ServiceContainer
        {
            get { return _serviceContainer; }
        }
    }
}