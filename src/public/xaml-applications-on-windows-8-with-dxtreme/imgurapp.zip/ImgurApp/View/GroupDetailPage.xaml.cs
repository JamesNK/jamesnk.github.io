﻿using System;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;
using DevExpress.UI.Xaml.Charts;
using ImgurApp.Data;
using DevExpress.UI.Xaml.Layout;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media.Imaging;

namespace ImgurApp
{
    /// <summary>
    /// A page that displays an overview of a single group, including a preview of the items
    /// within the group.
    /// </summary>
    public sealed partial class GroupDetailPage : DXPage
    {
        public GroupDetailPage()
        {
            this.InitializeComponent();

            this.Loaded += GroupDetailPage_Loaded;
        }

        void GroupDetailPage_Loaded(object sender, RoutedEventArgs e)
        {
            GroupDetailViewModel model = (GroupDetailViewModel)DataContext;
            int totalUpVotes = model.Group.Items.Sum(i => i.UpVotes);
            int totalDownVotes = model.Group.Items.Sum(i => i.DownVotes);

            ((DataPointCollection)doughnutChart.Series[0].Data)[0].Value = totalUpVotes;
            ((DataPointCollection)doughnutChart.Series[0].Data)[1].Value = totalDownVotes;
        }
    }
}
