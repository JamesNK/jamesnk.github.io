﻿using DevExpress.UI.Xaml.Layout;

namespace ImgurApp
{
    /// <summary>
    /// A page that displays a grouped collection of items.
    /// </summary>
    public sealed partial class GroupedItemsPage : DXPage
    {
        public GroupedItemsPage()
        {
            this.InitializeComponent();
        }
    }
}
