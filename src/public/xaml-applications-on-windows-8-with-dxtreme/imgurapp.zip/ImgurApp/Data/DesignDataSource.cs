﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImgurApp.Data
{
    public class DesignDataSource
    {
        private readonly ObservableCollection<Album> _allGroups = new ObservableCollection<Album>();

        public ObservableCollection<Album> TestGroups
        {
            get { return _allGroups; }
        }

        public DesignDataSource()
        {
            TestGroups.Clear();

            var scarlettAlbum = new Album { Title = "r/scarlettjohansson" };
            scarlettAlbum.Items.Add(CreateTestImage("Scarlett image 1", "Assets/Scarlett/0YfWX.jpg", scarlettAlbum));
            scarlettAlbum.Items.Add(CreateTestImage("Scarlett image 2", "Assets/Scarlett/8b08Q.jpg", scarlettAlbum));
            scarlettAlbum.Items.Add(CreateTestImage("Scarlett image 3", "Assets/Scarlett/P5zzF.jpg", scarlettAlbum));
            scarlettAlbum.Items.Add(CreateTestImage("Scarlett image 4", "Assets/Scarlett/rOO7T.jpg", scarlettAlbum));
            scarlettAlbum.Items.Add(CreateTestImage("Scarlett image 5", "Assets/Scarlett/VY8fL.jpg", scarlettAlbum));
            TestGroups.Add(scarlettAlbum);

            var awwAlbum = new Album {Title = "/r/aww"};
            awwAlbum.Items.Add(CreateTestImage("Aww image 1", "Assets/Aww/IrRdf.jpg", awwAlbum));
            awwAlbum.Items.Add(CreateTestImage("Aww image 2", "Assets/Aww/qeYIL.jpg", awwAlbum));
            awwAlbum.Items.Add(CreateTestImage("Aww image 3", "Assets/Aww/WJPW0.jpg", awwAlbum));
            TestGroups.Add(awwAlbum);
        }

        private Image CreateTestImage(string title, string imageUrl, Album album)
        {
            return new Image
                       {
                           Album = album,
                           Author = "James",
                           Bandwidth = "21.1gb",
                           DateTime = DateTime.Now,
                           DownVotes = 50,
                           Hash = "IrRdf",
                           UpVotes = 500,
                           Views = 6000,
                           Title = title,
                           ImageUrl = @"ms-appx:///" + imageUrl
                       };
        }
    }
}