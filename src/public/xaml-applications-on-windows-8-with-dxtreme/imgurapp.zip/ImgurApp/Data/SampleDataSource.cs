﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Windows.ApplicationModel.Resources.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ImgurApp.Data
{
    /// <summary>
    /// Creates a collection of groups and items with hard-coded content.
    /// 
    /// SampleDataSource initializes with placeholder data rather than live production
    /// data so that sample data is provided at both design-time and run-time.
    /// </summary>
    public sealed class SampleDataSource
    {
        private static readonly SampleDataSource _sampleDataSource = new SampleDataSource();

        private readonly ObservableCollection<Album> _allGroups = new ObservableCollection<Album>();

        public ObservableCollection<Album> AllGroups
        {
            get { return _allGroups; }
        }

        public static ObservableCollection<Album> GetGroups(string uniqueId)
        {
            if (!uniqueId.Equals("AllGroups"))
                throw new ArgumentException("Only 'AllGroups' is supported as a collection of groups");

            return _sampleDataSource.AllGroups;
        }

        public static Album GetGroup(string uniqueId)
        {
            // Simple linear search is acceptable for small data sets
            var matches = _sampleDataSource.AllGroups.Where((group) => group.Title.Equals(uniqueId));
            if (matches.Count() == 1) return matches.First();
            return null;
        }

        public static Image GetItem(string uniqueId)
        {
            // Simple linear search is acceptable for small data sets
            var matches =
                _sampleDataSource.AllGroups.SelectMany(group => group.Items).Where((item) => item.Hash.Equals(uniqueId));
            if (matches.Count() == 1) return matches.First();
            return null;
        }

        public static async Task<Album> LoadAlbum(string subReddit)
        {
            Album album = new Album();
            album.Title = subReddit;

            HttpClient httpClient = new HttpClient();
            string json = await httpClient.GetStringAsync("http://imgur.com" + subReddit + "/top.json");

            JObject o = JObject.Parse(json);
            foreach (JToken i in o["data"])
            {
                Image image = i.ToObject<Image>();
                image.Album = album;
                image.ImageUrl = string.Format("http://i.imgur.com/{0}.jpg", image.Hash);

                album.Items.Add(image);
            }

            return album;
        }

        public IList<Album> Load()
        {
            IList<string> subReddits = new List<string>
                                           {
                                               "/r/aww",
                                               "/r/scarlettjohansson"
                                           };

            var results = subReddits.Select(sr => LoadAlbum(sr)).ToArray();

            IList<Album> groups = new List<Album>();
            foreach (var item in results)
            {
                groups.Add(item.Result);
            }

            return groups;
        }

        public SampleDataSource()
        {
            var dispatcher = CoreWindow.GetForCurrentThread().Dispatcher;

            Task.Run(() =>
                         {
                             HttpClient httpClient = new HttpClient();

                             string url = "http://imgur.com/r/aww/top.json";

                             string json = httpClient.GetStringAsync(url).Result;

                             var groups = Load();

                             foreach (var item in groups)
                             {
                                 dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                                                     () => AllGroups.Add(item));
                             }
                         });
        }
    }
}