using System;
using Newtonsoft.Json;

namespace ImgurApp.Data
{
    public class Image
    {
        public string Hash { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Bandwidth { get; set; }
        public DateTime DateTime { get; set; }

        [JsonProperty("downs")]
        public int DownVotes { get; set; }

        [JsonProperty("ups")]
        public int UpVotes { get; set; }

        public int Views { get; set; }

        public string Subtitle
        {
            get { return Views + " views"; }
        }

        [JsonIgnore]
        public Album Album { get; set; }

        [JsonIgnore]
        public string ImageUrl { get; set; }
    }
}